<template>
  <div class="layout--full-page">
    <router-view></router-view>
  </div>
</template>
<script>
    export default {
    }
</script>
